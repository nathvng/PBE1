package prjExercício04;

public class Carro extends Veículo {

	// Métodos da SubClasse
	// Método Acelerar
	public void Acelerar() {
		if (this.velocidade >= 10) {
			System.out.println(this.velocidade + " ,veículo acelerando.");
		} else {
			this.velocidade += 10;
		}
	}

	// Método Frear
	public void Frear() {
		if (this.velocidade <= 10) {
			System.out.println(this.velocidade + " ,veículo freando.");
		} else {
			this.velocidade -= 10;
		}
	}
}
