package prjExercício04;

public class Veículo {

	// Atributos
	String marca;
	String modelo;
	int velocidade;

	// Construtores
			// Construtor Padrão
			public Veículo() {
				this.marca = "ford ";
				this.modelo = "sedan";
				this.velocidade = 50;
				
			}

			// Construtor Parametrizado
			public Veículo(String marca, String modelo, int velocidade) {
				this.marca = marca;
				this.modelo = modelo;
				this.velocidade = velocidade;
			}
			
			// Método Acelerar
			public void Acelerar() {
				if (this.velocidade >= 10) {
					System.out.println(this.velocidade + " ,veículo acelerando.");
				} else {
					this.velocidade += 10;
				}
			}
			
			// Método Frear
						public void Frear() {
							if (this.velocidade <= 10) {
								System.out.println(this.velocidade + " ,veículo freando.");
							} else {
								this.velocidade -= 10;
							}
						}
						
						
}
