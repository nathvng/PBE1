package prjExercicio3;

public class Animal {
	// Atributos
		String nome;
		int idade;
		String raça;
		
		// Construtores
		// Construtor Padrão
		public Animal() {
			this.nome = "Lulu ";
			this.idade = 0;
			this.raça = " Pug ";
			
		}

		// Construtor Parametrizado
		public Animal(String nome, int idade, String raça) {
			this.nome = nome;
			this.idade = idade;
			this.raça = raça;
		}
		
		//Método emitir som
		public void metodoEmitirSom() {
			System.out.println("Está emitindo som!");
		}
}
