package prjExercicio3;

public class Baleia extends Animal {
	
	//Métodos da SubClasse
		public void metodoNadar() {
			System.out.println(this.nome + " está nadando!");
		}
	}

