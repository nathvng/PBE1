package prjExercicio3;

public class Leão extends Animal {
		
		//Métodos da SubClasse
		public void metodoCacar() {
			System.out.println(this.nome + " está caçando!");
		}
	}


