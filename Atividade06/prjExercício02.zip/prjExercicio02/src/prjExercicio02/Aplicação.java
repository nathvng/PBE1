package prjExercicio02;

import prjExercio01.Carro;

public class Aplicação {

	public static void main(String[] args) {
		Livro livro1 = new Livro();
		livro1.titulo = "A vida de Nathália";
		livro1.numPaginas = 201;
		livro1.autor = "Nathália Venega";
		livro1.preco = 39.90;

		Livro livro2 = new Livro();
		livro2.titulo = "A vida de uma sereia";
		livro2.numPaginas = 200;
		livro2.autor = "Nathália Siqueira";
		livro2.preco = 29.90;

		Livro livro3 = new Livro();
		livro3.titulo = "A vida de uma borboleta";
		livro3.numPaginas = 202;
		livro3.autor = "Nathália Gabriele";
		livro3.preco = 19.90;

		livro1.exibirInfo();
		livro1.aplicarDesconto();
		livro1.exibirInfo();

		livro2.exibirInfo();
		livro2.aplicarDesconto();
		livro2.exibirInfo();

		livro3.exibirInfo();
		livro3.aplicarDesconto();
		livro3.exibirInfo();
	}

}
