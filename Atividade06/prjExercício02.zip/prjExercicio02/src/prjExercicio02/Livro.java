package prjExercicio02;

public class Livro {
	// Atributos
	String titulo;
	int numPaginas;
	String autor;
	double preco;

	// Construtores
	// Construtor Padrão (Sem parâmetros)
	public Livro() {

	}

	// Construtor Parametrizado
	public Livro(String titulo, int numPaginas, String autor, double preco) {
		this.titulo = titulo;
		this.numPaginas = numPaginas;
		this.autor = autor;
		this.preco = preco;
	}

	// Getters and Setters
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	// Método aplicarDesconto
	public void aplicarDesconto() {
		if (this.preco <= 15.00) {
			System.out.println(this.titulo + " ,diminuiu R$15,00");
		} else {
			this.preco -= 15.00;
		}
	}

	// 5.Método exibirInfo()
	public void exibirInfo() {
		System.out.println("Título: " + this.titulo);
		System.out.println("Número de páginas: " + this.numPaginas);
		System.out.println("Autor: " + this.autor);
		System.out.println("Preço: " + this.preco);
	}
}
