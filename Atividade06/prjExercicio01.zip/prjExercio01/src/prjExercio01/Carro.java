package prjExercio01;

public class Carro {

	// Atributos
	String marca;
	int ano;
	String modelo;
	int placa;

	// Construtores
	// Construtor Padrão (Sem parâmetros)
	public Carro() {

	}

	// Construtor Parametrizado
	public Carro(String marca, int ano, String modelo, int placa) {
		this.marca = marca;
		this.ano = ano;
		this.modelo = modelo;
		this.placa = placa;
	}

	public void exibirInfo() {
		 System.out.println("Marca: " + this.marca);
		 System.out.println("Ano: " + this.ano);
		 System.out.println("Modelo: " + this.modelo);
		 System.out.println("Placa: " + this.placa);
		 }
}
