package prjExercio01;

public class Aplicação {

	public static void main(String[] args) {
		Carro fiesta = new Carro();
		fiesta.marca = "ford";
		fiesta.ano = 2016;
		fiesta.modelo = "sedan";
		fiesta.placa = 5801;
	
	
	    Carro jeep = new Carro();
	    jeep.marca = "jeep";
	    jeep.ano = 2019;
	    jeep.modelo = "renegade";
	    jeep.placa = 2101;


	    fiesta.exibirInfo();
	
		jeep.exibirInfo();
}
}

