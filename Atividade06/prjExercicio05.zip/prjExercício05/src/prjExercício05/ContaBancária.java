package prjExercício05;

public class ContaBancária {
	// Atributos
	int numero;
	String titular;
	double saldo;

	// Construtores
	// Construtor Padrão
	public ContaBancária() {
		this.numero = 210108;
		this.titular = "Nathália";
		this.saldo = 110.000;

	}

	// Construtor Parametrizado
	public ContaBancária(int numero, String titular, double saldo) {
		this.numero = numero;
		this.titular = titular;
		this.saldo = saldo;
	}

	// Método Sacar
	public void Sacar() {
		if (this.saldo <= 110.000) {
			System.out.println(this.saldo + " , saque permitido.");
		} else {
			this.saldo -= 110.000;
		}
	}
}
