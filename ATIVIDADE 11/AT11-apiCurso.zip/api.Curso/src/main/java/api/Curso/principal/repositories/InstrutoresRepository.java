package api.Curso.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import api.Curso.principal.entities.Instrutores;

public interface InstrutoresRepository extends JpaRepository<Instrutores, Long> {

}
