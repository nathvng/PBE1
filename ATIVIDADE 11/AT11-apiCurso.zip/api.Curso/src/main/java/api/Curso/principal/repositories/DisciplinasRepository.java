package api.Curso.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import api.Curso.principal.entities.Disciplinas;

public interface DisciplinasRepository extends JpaRepository<Disciplinas, Long> {

}

