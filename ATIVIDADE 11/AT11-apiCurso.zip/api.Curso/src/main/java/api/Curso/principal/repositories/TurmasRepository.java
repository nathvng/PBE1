package api.Curso.principal.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import api.Curso.principal.entities.Turmas;

public interface TurmasRepository extends JpaRepository<Turmas, Long> {

}

