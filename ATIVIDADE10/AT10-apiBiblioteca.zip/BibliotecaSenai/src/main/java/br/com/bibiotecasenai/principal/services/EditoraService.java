package br.com.bibiotecasenai.principal.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibiotecasenai.principal.entities.Editora;
import br.com.bibiotecasenai.principal.repositories.EditoraRepository;

@Service
public class EditoraService {
	@Autowired
	private EditoraRepository EditoraRepository;
	
	public Editora saveEditora(Editora editora) {
		return EditoraRepository.save(editora);
	}

	public List<Editora> getAllEditora(){
		return EditoraRepository.findAll();
	}	
	
	public Editora getProdutoById(Long Id) {
		return EditoraRepository.findById(Id).orElse(null);
	}

	public void deleteEditora(Long id) {
		EditoraRepository.deleteById(id);
	}

	public Editora getEditoraById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
