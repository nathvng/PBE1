package br.com.bibiotecasenai.principal.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.bibiotecasenai.principal.entities.Livro;
import br.com.bibiotecasenai.principal.repositories.LivroRepository;

@Service
public class LivroService {

	@Autowired
	private LivroRepository LivroRepository;
	
	public Livro saveLivro(Livro livro) {
		return LivroRepository.save(livro);
	}

	public List<Livro> getAllLivro(){
		return LivroRepository.findAll();
	}	
	
	public Livro getProdutoById(Long Id) {
		return LivroRepository.findById(Id).orElse(null);
	}

	public void deleteLivro(Long id) {
		LivroRepository.deleteById(id);
	}

	public Livro getLivroById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
