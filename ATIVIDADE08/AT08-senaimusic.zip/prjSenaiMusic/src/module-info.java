/**
 * 
 */
/**
 * 
 */
module prjSenaiMusic {
}