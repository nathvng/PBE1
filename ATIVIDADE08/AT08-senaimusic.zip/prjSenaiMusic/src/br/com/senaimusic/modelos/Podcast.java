package br.com.senaimusic.modelos;

public class Podcast extends Audio {

	// Atributos
	private String apresentador;
	private String descricao;

	// Getters e Setters
	public String getapresentador() {
		return this.apresentador;
	}

	public void setapresentador(String apresentador) {
		this.apresentador = apresentador;
	}

	public String getdescricao() {
		return this.descricao;
	}

	public void setdescricao(String descricao) {
		this.descricao = descricao;
	}

	@Override
	public double getClasssificacao() {
		if (this.getTotalCurtidas() > 500) {
			return 10;
		} else {
			return 8;
		}
	}
}
