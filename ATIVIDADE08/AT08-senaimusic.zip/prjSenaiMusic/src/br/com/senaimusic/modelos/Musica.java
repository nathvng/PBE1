package br.com.senaimusic.modelos;

public class Musica  extends Audio {

	// Atributos
	private String album;
	private String cantor;
	private String genero;

	// Getters e Setters
	public String getalbum() {
		return this.album;
	}

	public void setalbum(String album) {
		this.album = album;
	}

	public String getcantor() {
		return this.cantor;
	}

	public void setcantor(String cantor) {
		this.cantor = cantor;
	}
	
	public String getgenero() {
		return this.genero;
	}

	public void setgenero(String genero) {
		this.genero = genero;
	}
	
	@Override
	public java.lang.Double getclasificacao() {
		if(this.getclasificacao() > 2000) {
			return (double) 10;
		} else {
			return (double) 7;
		}
	}
}
