package br.com.senaimusic.modelos;


public class Audio {
	//Atributos
   private String titulo;
   private int totalReproducoes;
   private int totalCurtidas;
   private double classificacao; 
   
   //Construtores
   public Audio() {
	   
   }
   
   public Audio(String titulo) {
	   this.titulo = titulo;
	   this.totalCurtidas = 0;
	   this.totalReproducoes = 0;
	   this.classificacao = 0;
   }
   
   //Getters e Setters
   public void setTitulo(String titulo) {
	   this.titulo = titulo;
   }
   
   public String getTitulo() {
	   return this.titulo;
   }
   
   public int getTotalReproducoes() {
	   return this.totalReproducoes;
   }
   
   public int getTotalCurtidas() {
	   return this.totalCurtidas;
   }
   
   public double getClassificacao() {
	   return this.classificacao;
   }
   
    //Metodos
   public void curte() {
	   this.totalCurtidas++;
   }
   
   public void reproduz() {
	   this.totalReproducoes++;
   }

public double getClasssificacao() {
	// TODO Auto-generated method stub
	return 0;
}

public Double getclasificacao() {
	// TODO Auto-generated method stub
	return null;
}
}
