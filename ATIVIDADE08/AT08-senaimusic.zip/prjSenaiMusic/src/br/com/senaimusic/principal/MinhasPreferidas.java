package br.com.senaimusic.principal;

import br.com.senaimusic.modelos.Audio;

public class MinhasPreferidas {

	
		
		public void incluir(Audio audio) {
			if(audio.getClassificacao() >= 9)  {
				System.out.println("Essa é top");
			} else {
				System.out.println("Esse nem tanto.");
				
			}
			
		}

	}


