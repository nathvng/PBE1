package br.com.bibliotecasenai.principal;

import br.com.bibliotecasenai.usuarios.Bibliotecario;
import br.com.bibliotecasenai.usuarios.Pessoa;
import br.com.bibliotecasenai.itens.Livro;
import br.com.bibliotecasenai.itens.Emprestimo;

public class Aplicacao {
    public static <Usuario> void main(String[] args) {
    	
        br.com.bibliotecasenai.usuarios.Usuario usuario1 = new br.com.bibliotecasenai.usuarios.Usuario("João", 25, "111.111.111-11");
        br.com.bibliotecasenai.usuarios.Usuario usuario2 = new br.com.bibliotecasenai.usuarios.Usuario("Maria", 30, "222.222.222-22");
        @SuppressWarnings("rawtypes")
		Bibliotecario bibliotecario = new Bibliotecario("Ana", 40, "M123");

      
        Livro[] livros = new Livro[10];
        for (int i = 0; i < 10; i++) {
            livros[i] = new Livro("Livro " + (i + 1), "Autor " + (i + 1), null);
        }

        Emprestimo emprestimo = new Emprestimo();

        for (int i = 0; i < 10; i++) {
            emprestimo.emprestarLivro(livros[i], (br.com.bibliotecasenai.usuarios.Usuario) usuario1);
        }

        for (int i = 0; i < 10; i++) {
            emprestimo.emprestarLivro(livros[i], (br.com.bibliotecasenai.usuarios.Usuario) usuario2);
        }
        
        for (int i = 0; i < 8; i++) {
            emprestimo.devolverLivro(livros[i], (br.com.bibliotecasenai.usuarios.Usuario) usuario1);
        }
        
        for (int i = 0; i < 8; i++) {
            emprestimo.devolverLivro(livros[i], (br.com.bibliotecasenai.usuarios.Usuario) usuario2);
        }

        System.out.println("Livros emprestados por " + ((Pessoa) usuario1).getNome() + ": " + ((br.com.bibliotecasenai.usuarios.Usuario) usuario1));
        System.out.println("Livros emprestados por " + ((Pessoa) usuario2).getNome() + ": " + ((br.com.bibliotecasenai.usuarios.Usuario) usuario2));
    }
}
