package br.com.bibliotecasenai.usuarios;

public class Usuario extends Pessoa {
    private String cpf;
    private int livrosEmprestados;

    public Usuario(String nome, int idade, String cpf) {
        super(nome, idade);
        this.cpf = cpf;
        this.livrosEmprestados = 0;
    }

    // Getters e Setters
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getLivrosEmprestados() {
        return livrosEmprestados;
    }

    public void setLivrosEmprestados(int livrosEmprestados) {
        this.livrosEmprestados = livrosEmprestados;
    }

	public String getNome() {
		// TODO Auto-generated method stub
		return null;
	}
}
