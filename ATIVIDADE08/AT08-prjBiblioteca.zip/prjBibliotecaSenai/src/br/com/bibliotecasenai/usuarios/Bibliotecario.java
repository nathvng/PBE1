package br.com.bibliotecasenai.usuarios;

import br.com.bibliotecasenai.itens.Livro;

@SuppressWarnings("hiding")
public class Bibliotecario<Usuario> extends Pessoa {
    private String matricula;

    public Bibliotecario(String nome, int idade, String matricula) {
        super(nome, idade);
        this.matricula = matricula;
    }

    public void realizarEmprestimo(Livro livro, Usuario usuario) {
        System.out.println(getNome() + " realizou empréstimo do livro " + livro.getTitulo() + " para " + ((Pessoa) usuario).getNome());
    }

    public String getNome() {
		
		return null;
	}

	public void devolverLivro(Livro livro, Usuario usuario) {
        System.out.println(getNome() + " recebeu a devolução do livro " + livro.getTitulo() + " de " + ((Pessoa) usuario).getNome());
    }

    // Getter e Setter
    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
}
