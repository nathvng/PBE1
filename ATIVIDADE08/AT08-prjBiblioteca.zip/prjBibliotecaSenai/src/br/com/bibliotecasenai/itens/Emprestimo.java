package br.com.bibliotecasenai.itens;

import br.com.bibliotecasenai.usuarios.Usuario;

public class Emprestimo {

	int numeroEmprestimo;

	public Emprestimo() {

		this.numeroEmprestimo = numeroEmprestimo;

	}

	public void emprestarLivro(Livro livro, Usuario usuario) {

		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados() + 1);

	}

	public void devolverLivro(Livro livro, Usuario usuario) {

		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados() - 1);

	}

}